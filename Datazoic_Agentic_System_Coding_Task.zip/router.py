class ToolRouter:
    """
    Tool selection layer.

    Production version:
        User request
             |
             v
        semantic retrieval
             |
             v
        top-k candidate tools
             |
             v
        LLM/reranker
             |
             v
        selected tool

    This demo uses a lightweight deterministic router so it can run
    without an external LLM/API key.
    """

    def __init__(self, registry):
        self.registry = registry

    def select_tool(self, user_request: str):
        candidates = self.registry.search(user_request)

        if not candidates:
            return None

        return candidates[0]
