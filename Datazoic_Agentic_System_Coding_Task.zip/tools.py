class BaseTool:
    name = "base_tool"
    description = ""
    keywords = []

    def execute(self, request: str):
        raise NotImplementedError


class InvoiceTool(BaseTool):
    name = "paypal_create_invoice"
    description = "Create and manage PayPal invoices."
    keywords = ["invoice", "invoices", "paypal", "bill", "billing"]

    def execute(self, request: str):
        return {
            "status": "success",
            "action": "create_invoice",
            "message": "Invoice API selected. In production, this would call PayPal."
        }


class SalesReportTool(BaseTool):
    name = "paypal_sales_report"
    description = "Retrieve sales volume and sales reports."
    keywords = ["sales", "sale", "volume", "report", "revenue", "last month"]

    def execute(self, request: str):
        return {
            "status": "success",
            "action": "sales_report",
            "period": "last month",
            "message": "Sales report API selected. In production, this would call PayPal."
        }


class DisputeTool(BaseTool):
    name = "paypal_dispute_lookup"
    description = "Check PayPal disputes for a user or transaction."
    keywords = ["dispute", "disputes", "user_123", "transaction", "chargeback"]

    def execute(self, request: str):
        return {
            "status": "success",
            "action": "dispute_lookup",
            "message": "Dispute API selected. In production, this would call PayPal."
        }


class RAGTool(BaseTool):
    name = "rag_pipeline"
    description = "Search the knowledge base and retrieve relevant product documentation."
    keywords = ["knowledge", "docs", "documentation", "guide", "product", "how"]

    def execute(self, request: str):
        return {
            "status": "success",
            "action": "rag_search",
            "message": "RAG pipeline selected. In production, this would query a vector database."
        }


class SystemSearchTool(BaseTool):
    name = "system_search"
    description = "Search system capabilities, available tools, request status, and logs."
    keywords = ["tools", "available", "capabilities", "status", "logs", "request"]

    def execute(self, request: str):
        return {
            "status": "success",
            "action": "system_search",
            "message": "System search selected. In production, this would query system metadata/logs."
        }
