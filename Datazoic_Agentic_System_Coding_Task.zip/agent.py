from router import ToolRouter
from tool_registry import ToolRegistry


class Agent:
    """
    Main agent.
    The agent receives natural-language requests, routes them to the
    appropriate tool, executes the tool, and returns the result.
    """

    def __init__(self):
        self.registry = ToolRegistry()
        self.router = ToolRouter(self.registry)

    def run(self, user_request: str):
        if not user_request:
            return "Please provide a request."

        try:
            tool = self.router.select_tool(user_request)

            if tool is None:
                return (
                    "I could not identify the required tool. "
                    "Try asking about invoices, sales, disputes, "
                    "RAG knowledge, or system/tool status."
                )

            result = tool.execute(user_request)

            return {
                "selected_tool": tool.name,
                "result": result
            }

        except Exception as exc:
            return {
                "error": "Tool execution failed",
                "details": str(exc)
            }
