from agent import Agent

def main():
    agent = Agent()

    print("Datazoic Scalable Agentic System")
    print("Type 'exit' to stop.\n")

    while True:
        user_input = input("User: ").strip()

        if user_input.lower() == "exit":
            break

        result = agent.run(user_input)
        print("Agent:", result)
        print()

if __name__ == "__main__":
    main()
