from tools import (
    InvoiceTool,
    SalesReportTool,
    DisputeTool,
    RAGTool,
    SystemSearchTool,
)


class ToolRegistry:
    """
    Central registry for all available tools.

    In a real system this registry can contain 100+ or 1000+ tools.
    The agent does not need every tool definition in its prompt.
    """

    def __init__(self):
        self.tools = [
            InvoiceTool(),
            SalesReportTool(),
            DisputeTool(),
            RAGTool(),
            SystemSearchTool(),
        ]

    def get_all_tools(self):
        return self.tools

    def search(self, query: str):
        """
        Return candidate tools using their descriptions/capabilities.
        This keeps routing separate from tool execution.
        """
        query_words = set(query.lower().split())
        candidates = []

        for tool in self.tools:
            searchable_text = (
                tool.name + " " +
                tool.description + " " +
                " ".join(tool.keywords)
            ).lower()

            score = sum(1 for word in query_words if word in searchable_text)

            if score > 0:
                candidates.append((score, tool))

        candidates.sort(key=lambda item: item[0], reverse=True)
        return [tool for _, tool in candidates]
